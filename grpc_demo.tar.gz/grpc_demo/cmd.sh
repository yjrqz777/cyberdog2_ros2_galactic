



python3 /SDCARD/workspace/cyberdog2_ros2_galactic/grpc_demo/grpc_teleop2.py 127.0.0.1 /SDCARD/workspace/cyberdog2_ros2_galactic/grpc_demo/cert/ca-cert.pem /SDCARD/workspace/cyberdog2_ros2_galactic/grpc_demo/cert/client-key.pem /SDCARD/workspace/cyberdog2_ros2_galactic/grpc_demo/cert/client-cert.pem
