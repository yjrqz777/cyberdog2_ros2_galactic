import os
import select
import sys

if os.name == 'nt':
    import msvcrt
    print('os.name is nt')
else:
    import termios
    import tty 
    print('os.name is', os.name)

import grpc
import json
import cyberdog_app_pb2
import cyberdog_app_pb2_grpc

class Client:
    def __init__(self, cyberdog_ip: str, ca_cert: str, client_key: str, client_cert: str):
        creds = grpc.ssl_channel_credentials(
            open(ca_cert, 'rb').read(),
            open(client_key, 'rb').read(),
            open(client_cert, 'rb').read())
        channel_options = (('grpc.ssl_target_name_override', 'cyberdog2.server'), 
                           ('grpc.default_authority', 'cyberdog2.server'))
        chennel = grpc.secure_channel(cyberdog_ip + ':50052', creds, channel_options)
        self.__stub = cyberdog_app_pb2_grpc.GrpcAppStub(chennel)
        print('Client is ready.')

    def sendMsg(self, name_code, params):
        try:
            result_list = self.__stub.sendMsg(
                cyberdog_app_pb2.SendRequest(
                    nameCode=name_code,
                    params=params))
            resp = list(result_list)
            print("111111")
            print(resp,end="\n")
            return resp
            print(resp)
            # json_str = json.dumps(resp)
            # print(json_str)
        except:
            print('failed to send msg')



'''
    bool is_version               # 是否返回当前版本信息， true: 是； false: 否；
    bool is_sn                    # 是否返回sn，true: 是； false: 否；
    bool is_nick_name             # 是否返回昵称，true: 是； false: 否；
    bool is_volume                # 是否返回音量，true: 是； false: 否；
    bool is_mic_state             # 是否返回MIC状态，true: 是； false: 否；
    bool is_voice_control         # 是否返回语音控制状态，true：是； false：否；
    bool is_wifi                  # 是否返回wifi信息
    bool is_bat_info              # 是否返回电池信息，true: 是； false: 否；
    bool is_motor_temper          # 是否返回电机温度
    bool is_audio_state           # 是否返回音箱板激活状态
    bool is_device_model          # 是否返回设备型号
    bool is_stand                 # 是否站立
    bool is_lowpower_control      # 是否返回低功耗状态
    string uid                    # 用户id
'''

class ProtoEncoder:
    def encodeVel(self):
        cmd = {}
        # cmd['enable'] = True
        # cmd["is_version"] = True
        cmd["type"] = 5
        # cmd["outdoor"] = False
        # cmd["map_name"] = "rue"
        # cmd["goalX"] = 0.49946996569633486
        # cmd["goalY"] = 0.032208945602178577
        # cmd["is_wifi"] = True
        # cmd["is_bat_info"] = True
        # cmd["is_motor_temper"] = True
        # cmd["is_audio_state"] = True
        # cmd["is_device_model"] = True
        # cmd["is_stand"] = True
        # cmd["is_lowpower_control"] = True
        # cmd["uid"] = "1234567890"


        return json.dumps(cmd)

if __name__ == '__main__':
    if len(sys.argv) < 5:
        print('Please input gRPC server IP, CA certificate, client key and client certificate')
        exit()
    grpc_client = Client(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
    encoder = ProtoEncoder()

    json_str = encoder.encodeVel()
    back = grpc_client.sendMsg(6009, json_str)
    print(back)
    # while True:
    print("---------")
    # responses = cyberdog_app_pb2.ReceiveRequest()
    # print(responses)


